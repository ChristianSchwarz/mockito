/*
 * Copyright (c) 2007 Mockito contributors
 * This program is made available under the terms of the MIT License.
 */

/**
 * JUnit integration support classes.
 */
package org.mockito.internal.junit;
