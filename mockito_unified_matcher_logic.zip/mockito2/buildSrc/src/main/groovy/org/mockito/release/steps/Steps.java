package org.mockito.release.steps;

public class Steps {

    public static ReleaseSteps newSteps() {
        return new DefaultReleaseSteps();
    }
}
